<?php

/**
 * This file has been auto-generated
 * by the Symfony Routing Component.
 */

return [
    false, // $matchHost
    [ // $staticRoutes
        '/cartproduct' => [[['_route' => 'cartproduct', '_controller' => 'App\\Controller\\CartproductController::index'], null, null, null, false, false, null]],
        '/' => [[['_route' => 'index', '_controller' => 'App\\Controller\\IndexController::index'], null, null, null, false, false, null]],
        '/contact' => [[['_route' => 'contact', '_controller' => 'App\\Controller\\IndexController::contact'], null, null, null, false, false, null]],
        '/cart' => [[['_route' => 'cart', '_controller' => 'App\\Controller\\IndexController::cart'], null, null, null, false, false, null]],
        '/payment' => [[['_route' => 'payment', '_controller' => 'App\\Controller\\IndexController::payment'], null, null, null, false, false, null]],
        '/success' => [[['_route' => 'success', '_controller' => 'App\\Controller\\IndexController::success'], null, null, null, false, false, null]],
        '/Addpromotion' => [[['_route' => 'Addpromotion', '_controller' => 'App\\Controller\\IndexController::addpromotion'], null, null, null, false, false, null]],
        '/product' => [[['_route' => 'product', '_controller' => 'App\\Controller\\ProductController::index'], null, null, null, false, false, null]],
        '/product/create' => [[['_route' => 'product_create', '_controller' => 'App\\Controller\\ProductController::create_product'], null, null, null, false, false, null]],
        '/user' => [[['_route' => 'user', '_controller' => 'App\\Controller\\UserController::index'], null, null, null, false, false, null]],
        '/useremail' => [[['_route' => 'useremail', '_controller' => 'App\\Controller\\UserController::useremail'], null, null, null, false, false, null]],
        '/users' => [[['_route' => 'users', '_controller' => 'App\\Controller\\UserController::users'], null, ['GET' => 0], null, false, false, null]],
        '/users/create' => [[['_route' => 'user_create', '_controller' => 'App\\Controller\\UserController::create_user'], null, null, null, false, false, null]],
    ],
    [ // $regexpList
        0 => '{^(?'
                .'|/_error/(\\d+)(?:\\.([^/]++))?(*:35)'
                .'|/cart/add/([^/]++)/([^/]++)(*:69)'
                .'|/removepromotion/([^/]++)(*:101)'
                .'|/users/remove/([^/]++)(*:131)'
            .')/?$}sDu',
    ],
    [ // $dynamicRoutes
        35 => [[['_route' => '_preview_error', '_controller' => 'error_controller::preview', '_format' => 'html'], ['code', '_format'], null, null, false, true, null]],
        69 => [[['_route' => 'add_to_cart', '_controller' => 'App\\Controller\\IndexController::addToCartAction'], ['name', 'price'], null, null, false, true, null]],
        101 => [[['_route' => 'removepromotion', '_controller' => 'App\\Controller\\IndexController::Removepromotion'], ['id'], null, null, false, true, null]],
        131 => [
            [['_route' => 'user_remove', '_controller' => 'App\\Controller\\UserController::remove_user'], ['id'], null, null, false, true, null],
            [null, null, null, null, false, false, 0],
        ],
    ],
    null, // $checkCondition
];
