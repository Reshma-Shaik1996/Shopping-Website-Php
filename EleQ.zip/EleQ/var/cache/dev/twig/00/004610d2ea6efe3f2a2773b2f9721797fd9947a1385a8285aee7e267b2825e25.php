<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Extension\SandboxExtension;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Source;
use Twig\Template;

/* product/index.html.twig */
class __TwigTemplate_5e4c52d98f2d28ef2c676bc5da22db4ee1d78a4b22df4dee3cc98dd9e54a9711 extends Template
{
    private $source;
    private $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->blocks = [
            'title' => [$this, 'block_title'],
            'body' => [$this, 'block_body'],
        ];
    }

    protected function doGetParent(array $context)
    {
        // line 1
        return "base.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = [])
    {
        $macros = $this->macros;
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02 = $this->extensions["Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension"];
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->enter($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "template", "product/index.html.twig"));

        $this->parent = $this->loadTemplate("base.html.twig", "product/index.html.twig", 1);
        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->leave($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof);

    }

    // line 3
    public function block_title($context, array $blocks = [])
    {
        $macros = $this->macros;
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02 = $this->extensions["Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension"];
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->enter($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "block", "title"));

        echo "Hello ProductController!";
        
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->leave($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof);

    }

    // line 5
    public function block_body($context, array $blocks = [])
    {
        $macros = $this->macros;
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02 = $this->extensions["Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension"];
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->enter($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "block", "body"));

        // line 6
        echo "<style>
    .example-wrapper { margin: 1em auto; max-width: 800px; width: 95%; font: 18px/1.5 sans-serif; }
    .example-wrapper code { background: #F5F5F5; padding: 2px 6px; }
</style>

<form action=\"\">
  <div class=\"container\">
    <h1>Register</h1>
    <p>Please fill in this form to create an product</p>
    <hr>

    <label for=\"product_id\"><b>product Id</b></label>
    <input type=\"text\" placeholder=\"Enter product Id\" name=\"product_id\" required>

    <label for=\"name\"><b>Name</b></label>
    <input type=\"text\" placeholder=\"Enter Name\" name=\"name\" required>

    <label for=\"image\"><b>image path</b></label>
    <input type=\"text\" placeholder=\"Image Path\" name=\"image\" required>
   
 <label for=\"price\"><b>Price</b></label>
    <input type=\"text\" placeholder=\"Price\" name=\"price\" required>
    <label for=\"description\"><b>Description</b></label>
    <input type=\"text\" placeholder=\"description name=\"description\" required>
   
  
    <button type=\"submit\" class=\"addbtn\">Add product</button>
  </div>

  
</form>
";
        
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->leave($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof);

    }

    public function getTemplateName()
    {
        return "product/index.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  73 => 6,  66 => 5,  53 => 3,  36 => 1,);
    }

    public function getSourceContext()
    {
        return new Source("{% extends 'base.html.twig' %}

{% block title %}Hello ProductController!{% endblock %}

{% block body %}
<style>
    .example-wrapper { margin: 1em auto; max-width: 800px; width: 95%; font: 18px/1.5 sans-serif; }
    .example-wrapper code { background: #F5F5F5; padding: 2px 6px; }
</style>

<form action=\"\">
  <div class=\"container\">
    <h1>Register</h1>
    <p>Please fill in this form to create an product</p>
    <hr>

    <label for=\"product_id\"><b>product Id</b></label>
    <input type=\"text\" placeholder=\"Enter product Id\" name=\"product_id\" required>

    <label for=\"name\"><b>Name</b></label>
    <input type=\"text\" placeholder=\"Enter Name\" name=\"name\" required>

    <label for=\"image\"><b>image path</b></label>
    <input type=\"text\" placeholder=\"Image Path\" name=\"image\" required>
   
 <label for=\"price\"><b>Price</b></label>
    <input type=\"text\" placeholder=\"Price\" name=\"price\" required>
    <label for=\"description\"><b>Description</b></label>
    <input type=\"text\" placeholder=\"description name=\"description\" required>
   
  
    <button type=\"submit\" class=\"addbtn\">Add product</button>
  </div>

  
</form>
{% endblock %}
", "product/index.html.twig", "/Applications/MAMP/htdocs/EleQ/templates/product/index.html.twig");
    }
}
