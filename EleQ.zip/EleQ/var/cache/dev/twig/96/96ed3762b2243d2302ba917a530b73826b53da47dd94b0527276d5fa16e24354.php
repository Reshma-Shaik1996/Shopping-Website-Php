<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Extension\SandboxExtension;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Source;
use Twig\Template;

/* product/menu.html.twig */
class __TwigTemplate_250aa50f89094487e21a26eb74d1d585188c0083b06a362028f7c974e1bfad3c extends Template
{
    private $source;
    private $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->blocks = [
            'title' => [$this, 'block_title'],
            'body' => [$this, 'block_body'],
        ];
    }

    protected function doGetParent(array $context)
    {
        // line 1
        return "base.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = [])
    {
        $macros = $this->macros;
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02 = $this->extensions["Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension"];
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->enter($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "template", "product/menu.html.twig"));

        $this->parent = $this->loadTemplate("base.html.twig", "product/menu.html.twig", 1);
        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->leave($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof);

    }

    // line 3
    public function block_title($context, array $blocks = [])
    {
        $macros = $this->macros;
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02 = $this->extensions["Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension"];
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->enter($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "block", "title"));

        echo "Hello ProductController!";
        
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->leave($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof);

    }

    // line 5
    public function block_body($context, array $blocks = [])
    {
        $macros = $this->macros;
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02 = $this->extensions["Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension"];
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->enter($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "block", "body"));

        // line 6
        echo "<style>
    .example-wrapper { margin: 1em auto; max-width: 800px; width: 95%; font: 18px/1.5 sans-serif; }
    .example-wrapper code { background: #F5F5F5; padding: 2px 6px; }
</style>
<h1>Welcome Admin!!</h1>
";
        // line 13
        echo "<form action=\"";
        echo $this->extensions['Symfony\Bridge\Twig\Extension\RoutingExtension']->getPath("product_create");
        echo "\">
  <div class=\"container\">
    <h1>Add Product</h1>
    <hr>

    <label for=\"product_id\"><b>product_id</b></label>
    <input type=\"text\" placeholder=\"Enter product_id\" name=\"product_id\" required>

    <label for=\"name\"><b>name</b></label>
    <input type=\"text\" placeholder=\"Enter name\" name=\"name\" required>

    <label for=\"image\"><b>image</b></label>
    <input type=\"text\" placeholder=\"image\" name=\"image\" required>
   <label for=\"price\"><b>price</b></label>
    <input type=\"number\" placeholder=\"Enter price\" name=\"price\" required>
<label for=\"description\"><b>description</b></label>
    <input type=\"text\" placeholder=\"Enter description\" name=\"description\" required>
    <button type=\"submit\" class=\"productAddbtn\">product Add</button>

    <hr>

  </div>

</form>
 ";
        // line 38
        echo "
<form action=\"";
        // line 39
        echo $this->extensions['Symfony\Bridge\Twig\Extension\RoutingExtension']->getPath("Addpromotion");
        echo ", method=\"POST\">
  <div class=\"promotion\">
    <h1>set promotion</h1>
    <hr>

    <label for=\"promotion\"><b>promotion</b></label>
   
    <input type=\"text\" placeholder=\"Enter promotion\" name=\"promotion\" required>
    <button type=\"submit\" class=\"promotionAddbtn\">promotion Add</button>

</form>

";
        
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->leave($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof);

    }

    public function getTemplateName()
    {
        return "product/menu.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  111 => 39,  108 => 38,  80 => 13,  73 => 6,  66 => 5,  53 => 3,  36 => 1,);
    }

    public function getSourceContext()
    {
        return new Source("{% extends 'base.html.twig' %}

{% block title %}Hello ProductController!{% endblock %}

{% block body %}
<style>
    .example-wrapper { margin: 1em auto; max-width: 800px; width: 95%; font: 18px/1.5 sans-serif; }
    .example-wrapper code { background: #F5F5F5; padding: 2px 6px; }
</style>
<h1>Welcome Admin!!</h1>
{# <a href= \"{{path='AddProduct'}}\">Click here to add product</a>
                        #}
<form action=\"{{path('product_create')}}\">
  <div class=\"container\">
    <h1>Add Product</h1>
    <hr>

    <label for=\"product_id\"><b>product_id</b></label>
    <input type=\"text\" placeholder=\"Enter product_id\" name=\"product_id\" required>

    <label for=\"name\"><b>name</b></label>
    <input type=\"text\" placeholder=\"Enter name\" name=\"name\" required>

    <label for=\"image\"><b>image</b></label>
    <input type=\"text\" placeholder=\"image\" name=\"image\" required>
   <label for=\"price\"><b>price</b></label>
    <input type=\"number\" placeholder=\"Enter price\" name=\"price\" required>
<label for=\"description\"><b>description</b></label>
    <input type=\"text\" placeholder=\"Enter description\" name=\"description\" required>
    <button type=\"submit\" class=\"productAddbtn\">product Add</button>

    <hr>

  </div>

</form>
 {# <a href= \"{{path='AddProduct'}}\">Click here to Change promotion</a> #}

<form action=\"{{path('Addpromotion')}}, method=\"POST\">
  <div class=\"promotion\">
    <h1>set promotion</h1>
    <hr>

    <label for=\"promotion\"><b>promotion</b></label>
   
    <input type=\"text\" placeholder=\"Enter promotion\" name=\"promotion\" required>
    <button type=\"submit\" class=\"promotionAddbtn\">promotion Add</button>

</form>

{% endblock %}
", "product/menu.html.twig", "/Applications/MAMP/htdocs/EleQ/templates/product/menu.html.twig");
    }
}
