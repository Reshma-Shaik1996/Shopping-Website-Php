<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Extension\SandboxExtension;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Source;
use Twig\Template;

/* product.html.twig */
class __TwigTemplate_291b6160b466b11bbab9cf89fe9e26965c6892e0af655650273935fce8abc4f5 extends Template
{
    private $source;
    private $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->blocks = [
            'active_contact' => [$this, 'block_active_contact'],
            'body' => [$this, 'block_body'],
            'javascripts' => [$this, 'block_javascripts'],
        ];
    }

    protected function doGetParent(array $context)
    {
        // line 1
        return "base.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = [])
    {
        $macros = $this->macros;
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02 = $this->extensions["Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension"];
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->enter($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "template", "product.html.twig"));

        $this->parent = $this->loadTemplate("base.html.twig", "product.html.twig", 1);
        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->leave($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof);

    }

    // line 3
    public function block_active_contact($context, array $blocks = [])
    {
        $macros = $this->macros;
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02 = $this->extensions["Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension"];
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->enter($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "block", "active_contact"));

        echo " active ";
        
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->leave($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof);

    }

    // line 7
    public function block_body($context, array $blocks = [])
    {
        $macros = $this->macros;
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02 = $this->extensions["Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension"];
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->enter($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "block", "body"));

        // line 8
        echo "<style>

.btn {
  background-color: black;
  color: black;
  padding: 12px;
  margin: 10px 0;
  border: none;
  width: 100%;
  border-radius: 3px;
  cursor: pointer;
  font-size: 17px;
}

.btn:hover {
  background-color: grey;
}


</style>
<div class=\"jumbotron\">
<div class=\"container\">
    <h1>Welcome to EleQ!</h1>
    <p>We Sell Apple Products</P>
   <div class=\"container\">
    <div class=\"row\">
            ";
        // line 35
        echo "        ";
        $context['_parent'] = $context;
        $context['_seq'] = twig_ensure_traversable((isset($context["products"]) || array_key_exists("products", $context) ? $context["products"] : (function () { throw new RuntimeError('Variable "products" does not exist.', 35, $this->source); })()));
        foreach ($context['_seq'] as $context["_key"] => $context["product"]) {
            // line 36
            echo "        <div class=\"col-sm\">
            <div class=\"img-thumbnail text-center\">
                <img src=\"";
            // line 38
            echo twig_escape_filter($this->env, $this->extensions['Symfony\Bridge\Twig\Extension\AssetExtension']->getAssetUrl(twig_get_attribute($this->env, $this->source, $context["product"], "image", [], "array", false, false, false, 38)), "html", null, true);
            echo "\" class=\"rounded\" width=\"150\">
                <p>";
            // line 39
            echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, $context["product"], "name", [], "array", false, false, false, 39), "html", null, true);
            echo "</p>
                <p>";
            // line 40
            echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, $context["product"], "price", [], "array", false, false, false, 40), "html", null, true);
            echo "</p>
               <button type=\"submit\" class=\"btn btn-primary\" onclick= \"\" ><a href= \"";
            // line 41
            echo twig_escape_filter($this->env, $this->extensions['Symfony\Bridge\Twig\Extension\RoutingExtension']->getPath("add_to_cart", ["name" => twig_get_attribute($this->env, $this->source, $context["product"], "name", [], "array", false, false, false, 41), "price" => twig_get_attribute($this->env, $this->source, $context["product"], "price", [], "array", false, false, false, 41)]), "html", null, true);
            echo "
\">Add to Cart</a></button>
            </div>
        </div>
        ";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['product'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 46
        echo "  ";
        // line 47
        echo "        ";
        // line 56
        echo "    </div>
</div>
<div>
<br><br><br>
 <a class=\"nav-link\" data-toggle=\"modal\" data-target=\"#promotionModal\" href=\"\">Promotions</a>

</div>
";
        // line 63
        $this->displayBlock('javascripts', $context, $blocks);
        // line 64
        echo "<div class=\"modal fade\" id=\"promotionModal\" tabindex=\"-1\" role=\"dialog\">
        <div class=\"modal-dialog\" role=\"document\">
            <div class=\"modal-content\">
                <div class=\"modal-header\">
                    <h5 class=\"modal-title\">Promotionss!!!</h5>
                    <button type=\"button\" class=\"close\" data-dismiss=\"modal\">
                        <span>&times;</span>
                    </button>
                </div>
                   <h1>Welcome to EleQ!</h1>
    <p>Buy one and seconf one is 10% off!</p>

            </div>
        </div>
    </div>
";
        
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->leave($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof);

    }

    // line 63
    public function block_javascripts($context, array $blocks = [])
    {
        $macros = $this->macros;
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02 = $this->extensions["Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension"];
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->enter($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "block", "javascripts"));

        
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->leave($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof);

    }

    public function getTemplateName()
    {
        return "product.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  171 => 63,  149 => 64,  147 => 63,  138 => 56,  136 => 47,  134 => 46,  123 => 41,  119 => 40,  115 => 39,  111 => 38,  107 => 36,  102 => 35,  74 => 8,  67 => 7,  54 => 3,  37 => 1,);
    }

    public function getSourceContext()
    {
        return new Source("{% extends ('base.html.twig') %}

{% block active_contact %} active {% endblock %}



{% block body %}
<style>

.btn {
  background-color: black;
  color: black;
  padding: 12px;
  margin: 10px 0;
  border: none;
  width: 100%;
  border-radius: 3px;
  cursor: pointer;
  font-size: 17px;
}

.btn:hover {
  background-color: grey;
}


</style>
<div class=\"jumbotron\">
<div class=\"container\">
    <h1>Welcome to EleQ!</h1>
    <p>We Sell Apple Products</P>
   <div class=\"container\">
    <div class=\"row\">
            {# <form action=\"\" method=\"POST\"> #}
        {% for product in products %}
        <div class=\"col-sm\">
            <div class=\"img-thumbnail text-center\">
                <img src=\"{{ asset(product['image']) }}\" class=\"rounded\" width=\"150\">
                <p>{{ product['name'] }}</p>
                <p>{{ product['price'] }}</p>
               <button type=\"submit\" class=\"btn btn-primary\" onclick= \"\" ><a href= \"{{path('add_to_cart',{name:  product['name'], price:  product['price']})}}
\">Add to Cart</a></button>
            </div>
        </div>
        {% endfor %}
  {# </form> #}
        {# {% for prom in promotionArray %}

                <tr>
                    <td>{{ prom }}</td>
                    
                    <td><a href=\"{{ path('removepromotion', {id: loop.index}) }}\">Remove</a></td>
                </tr>
            {% endfor %}
           #}
    </div>
</div>
<div>
<br><br><br>
 <a class=\"nav-link\" data-toggle=\"modal\" data-target=\"#promotionModal\" href=\"\">Promotions</a>

</div>
{% block javascripts %}{% endblock %}
<div class=\"modal fade\" id=\"promotionModal\" tabindex=\"-1\" role=\"dialog\">
        <div class=\"modal-dialog\" role=\"document\">
            <div class=\"modal-content\">
                <div class=\"modal-header\">
                    <h5 class=\"modal-title\">Promotionss!!!</h5>
                    <button type=\"button\" class=\"close\" data-dismiss=\"modal\">
                        <span>&times;</span>
                    </button>
                </div>
                   <h1>Welcome to EleQ!</h1>
    <p>Buy one and seconf one is 10% off!</p>

            </div>
        </div>
    </div>
{% endblock %}

  ", "product.html.twig", "/Applications/MAMP/htdocs/EleQ/templates/product.html.twig");
    }
}
