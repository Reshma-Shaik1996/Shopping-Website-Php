<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Extension\SandboxExtension;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Source;
use Twig\Template;

/* base.html.twig */
class __TwigTemplate_ef07bfc331bf7a03f13d4fc2593ee8bc53ecdddb1f13ae850041fd18033af1c1 extends Template
{
    private $source;
    private $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->parent = false;

        $this->blocks = [
            'title' => [$this, 'block_title'],
            'stylesheets' => [$this, 'block_stylesheets'],
            'navbarCollapse' => [$this, 'block_navbarCollapse'],
            'active_products' => [$this, 'block_active_products'],
            'active_contact' => [$this, 'block_active_contact'],
            'body' => [$this, 'block_body'],
            'javascripts' => [$this, 'block_javascripts'],
        ];
    }

    protected function doDisplay(array $context, array $blocks = [])
    {
        $macros = $this->macros;
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02 = $this->extensions["Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension"];
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->enter($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "template", "base.html.twig"));

        // line 1
        echo "


<!DOCTYPE html>
<html>
    <head>
        <meta charset=\"UTF-8\">
        <title>";
        // line 8
        $this->displayBlock('title', $context, $blocks);
        echo "</title>
        <link href=\"https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css\" rel=\"stylesheet\">
        <script src=\"https://code.jquery.com/jquery-3.4.1.min.js\"></script>
        <script src=\"https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js\"></script>
        ";
        // line 12
        $this->displayBlock('stylesheets', $context, $blocks);
        // line 13
        echo "    </head>
    <body>
    <nav class=\"navbar navbar-expand-lg navbar-dark bg-dark\">
        <div class=\"container\">
            <a class=\"navbar-brand\" href=\"\">EleQ</a>
            <button class=\"navbar-toggler\" type=\"button\" data-toggle=\"collapse\" data-target=\"#baseNavbar\">
                <span class=\"navbar-toggler-icon\"></span>
            </button>

            ";
        // line 22
        $this->displayBlock('navbarCollapse', $context, $blocks);
        // line 47
        echo "        </div>
    </nav>
    ";
        // line 49
        $this->displayBlock('body', $context, $blocks);
        // line 50
        echo "    ";
        $this->displayBlock('javascripts', $context, $blocks);
        // line 51
        echo "    <div class=\"modal fade\" id=\"registerModal\" tabindex=\"-1\" role=\"dialog\">
        <div class=\"modal-dialog\" role=\"document\">
            <div class=\"modal-content\">
                <div class=\"modal-header\">
                    <h5 class=\"modal-title\">Registration Form</h5>
                    <button type=\"button\" class=\"close\" data-dismiss=\"modal\">
                        <span>&times;</span>
                    </button>
                </div>
                <form action=\"\" method=\"POST\">
";
        // line 63
        echo "                    <div class=\"modal-body\">
                        <div class=\"form-group\">
                            <label for=\"usernameInput\">Username</label>
                            <input name=\"username\" type=\"text\" class=\"form-control\" id=\"usernameInput\" placeholder=\"Enter username\">
                        </div>
                        <div class=\"form-group\">
                            <label for=\"passwordInput\">Password</label>
                            <input name=\"password\" type=\"password\" class=\"form-control\" id=\"passwordInput\" placeholder=\"Enter password\">
                        </div>
                    </div>
                    <div class=\"modal-footer\">
                        <button type=\"button\" class=\"btn btn-secondary\" data-dismiss=\"modal\">Close</button>
                        <button type=\"submit\" class=\"btn btn-primary\">Register</button>
                    </div>
                </form>
            </div>
        </div>
    </div>
    <div class=\"modal fade\" id=\"signinModal\" tabindex=\"-1\" role=\"dialog\">
        <div class=\"modal-dialog\" role=\"document\">
            <div class=\"modal-content\">
                <div class=\"modal-header\">
                    <h5 class=\"modal-title\">SignIn Form</h5>
                    <button type=\"button\" class=\"close\" data-dismiss=\"modal\">
                        <span>&times;</span>
                    </button>
                </div>
                <form action=\"\" method=\"POST\">
";
        // line 93
        echo "                    <div class=\"modal-body\">
                        <div class=\"form-group\">
                            <label for=\"usernameInput\">Username</label>
                            <input name=\"username\" type=\"text\" class=\"form-control\" id=\"usernameInput\" placeholder=\"Enter username\">
                        </div>
                        <div class=\"form-group\">
                            <label for=\"passwordInput\">Password</label>
                            <input name=\"password\" type=\"password\" class=\"form-control\" id=\"passwordInput\" placeholder=\"Enter password\">
                        </div>
                    </div>
                    <div class=\"modal-footer\">
                        <button type=\"button\" class=\"btn btn-secondary\" data-dismiss=\"modal\">Close</button>
                        <button type=\"submit\" class=\"btn btn-primary\">Sign In</button>
                    </div>
                </form>
            </div>
        </div>
    </div>
    </body>
</html>
";
        
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->leave($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof);

    }

    // line 8
    public function block_title($context, array $blocks = [])
    {
        $macros = $this->macros;
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02 = $this->extensions["Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension"];
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->enter($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "block", "title"));

        echo "Welcome!";
        
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->leave($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof);

    }

    // line 12
    public function block_stylesheets($context, array $blocks = [])
    {
        $macros = $this->macros;
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02 = $this->extensions["Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension"];
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->enter($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "block", "stylesheets"));

        
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->leave($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof);

    }

    // line 22
    public function block_navbarCollapse($context, array $blocks = [])
    {
        $macros = $this->macros;
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02 = $this->extensions["Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension"];
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->enter($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "block", "navbarCollapse"));

        // line 23
        echo "            <div class=\"collapse navbar-collapse\" id=\"baseNavbar\">
                <ul class=\"navbar-nav mr-auto\">
                    
                    <li class=\"nav-item ";
        // line 26
        $this->displayBlock('active_products', $context, $blocks);
        echo "\">
                        <a class=\"nav-link\" href=\"\">Products</a>
                    </li>
                    <li class=\"nav-item ";
        // line 29
        $this->displayBlock('active_contact', $context, $blocks);
        echo "\">
                        <a class=\"nav-link\" href=\"";
        // line 30
        echo $this->extensions['Symfony\Bridge\Twig\Extension\RoutingExtension']->getPath("contact");
        echo " \">Contact Us</a>
                        ";
        // line 32
        echo "                    </li>
                </ul>
                <ul class=\"navbar-nav ml-auto\">
                    <li class=\"nav-item\">
                        <a class=\"nav-link\" data-toggle=\"modal\" data-target=\"#registerModal\" href=\"\">Register</a>
                    </li>
                    <li class=\"nav-item\">
                        <a class=\"nav-link\" data-toggle=\"modal\" data-target=\"#signinModal\" href=\"\">Sign In</a>
                    </li>
                    <li class=\"nav-item\">
                        <a class=\"nav-link\" data-toggle=\"modal\" data-target=\"#cartModal\" href=\"\">Cart</a>
                    </li>
                </ul>
            </div>
            ";
        
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->leave($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof);

    }

    // line 26
    public function block_active_products($context, array $blocks = [])
    {
        $macros = $this->macros;
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02 = $this->extensions["Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension"];
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->enter($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "block", "active_products"));

        echo " ";
        
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->leave($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof);

    }

    // line 29
    public function block_active_contact($context, array $blocks = [])
    {
        $macros = $this->macros;
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02 = $this->extensions["Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension"];
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->enter($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "block", "active_contact"));

        echo " ";
        
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->leave($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof);

    }

    // line 49
    public function block_body($context, array $blocks = [])
    {
        $macros = $this->macros;
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02 = $this->extensions["Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension"];
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->enter($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "block", "body"));

        
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->leave($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof);

    }

    // line 50
    public function block_javascripts($context, array $blocks = [])
    {
        $macros = $this->macros;
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02 = $this->extensions["Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension"];
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->enter($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "block", "javascripts"));

        
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->leave($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof);

    }

    public function getTemplateName()
    {
        return "base.html.twig";
    }

    public function getDebugInfo()
    {
        return array (  266 => 50,  254 => 49,  241 => 29,  228 => 26,  207 => 32,  203 => 30,  199 => 29,  193 => 26,  188 => 23,  181 => 22,  169 => 12,  156 => 8,  129 => 93,  99 => 63,  87 => 51,  84 => 50,  82 => 49,  78 => 47,  76 => 22,  65 => 13,  63 => 12,  56 => 8,  47 => 1,);
    }

    public function getSourceContext()
    {
        return new Source("


<!DOCTYPE html>
<html>
    <head>
        <meta charset=\"UTF-8\">
        <title>{% block title %}Welcome!{% endblock %}</title>
        <link href=\"https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css\" rel=\"stylesheet\">
        <script src=\"https://code.jquery.com/jquery-3.4.1.min.js\"></script>
        <script src=\"https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js\"></script>
        {% block stylesheets %}{% endblock %}
    </head>
    <body>
    <nav class=\"navbar navbar-expand-lg navbar-dark bg-dark\">
        <div class=\"container\">
            <a class=\"navbar-brand\" href=\"\">EleQ</a>
            <button class=\"navbar-toggler\" type=\"button\" data-toggle=\"collapse\" data-target=\"#baseNavbar\">
                <span class=\"navbar-toggler-icon\"></span>
            </button>

            {% block navbarCollapse %}
            <div class=\"collapse navbar-collapse\" id=\"baseNavbar\">
                <ul class=\"navbar-nav mr-auto\">
                    
                    <li class=\"nav-item {% block active_products %} {% endblock %}\">
                        <a class=\"nav-link\" href=\"\">Products</a>
                    </li>
                    <li class=\"nav-item {% block active_contact %} {% endblock %}\">
                        <a class=\"nav-link\" href=\"{{ path('contact') }} \">Contact Us</a>
                        {# #}
                    </li>
                </ul>
                <ul class=\"navbar-nav ml-auto\">
                    <li class=\"nav-item\">
                        <a class=\"nav-link\" data-toggle=\"modal\" data-target=\"#registerModal\" href=\"\">Register</a>
                    </li>
                    <li class=\"nav-item\">
                        <a class=\"nav-link\" data-toggle=\"modal\" data-target=\"#signinModal\" href=\"\">Sign In</a>
                    </li>
                    <li class=\"nav-item\">
                        <a class=\"nav-link\" data-toggle=\"modal\" data-target=\"#cartModal\" href=\"\">Cart</a>
                    </li>
                </ul>
            </div>
            {% endblock %}
        </div>
    </nav>
    {% block body %}{% endblock %}
    {% block javascripts %}{% endblock %}
    <div class=\"modal fade\" id=\"registerModal\" tabindex=\"-1\" role=\"dialog\">
        <div class=\"modal-dialog\" role=\"document\">
            <div class=\"modal-content\">
                <div class=\"modal-header\">
                    <h5 class=\"modal-title\">Registration Form</h5>
                    <button type=\"button\" class=\"close\" data-dismiss=\"modal\">
                        <span>&times;</span>
                    </button>
                </div>
                <form action=\"\" method=\"POST\">
{# 
              action  {{ path('user_create') }} #}
                    <div class=\"modal-body\">
                        <div class=\"form-group\">
                            <label for=\"usernameInput\">Username</label>
                            <input name=\"username\" type=\"text\" class=\"form-control\" id=\"usernameInput\" placeholder=\"Enter username\">
                        </div>
                        <div class=\"form-group\">
                            <label for=\"passwordInput\">Password</label>
                            <input name=\"password\" type=\"password\" class=\"form-control\" id=\"passwordInput\" placeholder=\"Enter password\">
                        </div>
                    </div>
                    <div class=\"modal-footer\">
                        <button type=\"button\" class=\"btn btn-secondary\" data-dismiss=\"modal\">Close</button>
                        <button type=\"submit\" class=\"btn btn-primary\">Register</button>
                    </div>
                </form>
            </div>
        </div>
    </div>
    <div class=\"modal fade\" id=\"signinModal\" tabindex=\"-1\" role=\"dialog\">
        <div class=\"modal-dialog\" role=\"document\">
            <div class=\"modal-content\">
                <div class=\"modal-header\">
                    <h5 class=\"modal-title\">SignIn Form</h5>
                    <button type=\"button\" class=\"close\" data-dismiss=\"modal\">
                        <span>&times;</span>
                    </button>
                </div>
                <form action=\"\" method=\"POST\">
{# 
              action  {{ path('user_create') }} #}
                    <div class=\"modal-body\">
                        <div class=\"form-group\">
                            <label for=\"usernameInput\">Username</label>
                            <input name=\"username\" type=\"text\" class=\"form-control\" id=\"usernameInput\" placeholder=\"Enter username\">
                        </div>
                        <div class=\"form-group\">
                            <label for=\"passwordInput\">Password</label>
                            <input name=\"password\" type=\"password\" class=\"form-control\" id=\"passwordInput\" placeholder=\"Enter password\">
                        </div>
                    </div>
                    <div class=\"modal-footer\">
                        <button type=\"button\" class=\"btn btn-secondary\" data-dismiss=\"modal\">Close</button>
                        <button type=\"submit\" class=\"btn btn-primary\">Sign In</button>
                    </div>
                </form>
            </div>
        </div>
    </div>
    </body>
</html>
", "base.html.twig", "/Applications/MAMP/htdocs/EleQ/templates/base.html.twig");
    }
}
