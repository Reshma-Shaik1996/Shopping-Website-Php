<?php

namespace App\Entity;

use Doctrine\Common\Collections\ArrayCollection;
use Doctrine\Common\Collections\Collection;
use Doctrine\ORM\Mapping as ORM;

/**
 * @ORM\Entity(repositoryClass="App\Repository\CartRepository")
 */
class Cart
{
    /**
     * @ORM\Id()
     * @ORM\GeneratedValue()
     * @ORM\Column(type="integer")
     */
    private $id;

    /**
     * @ORM\Column(type="string", length=255)
     */
    private $cart_id;

    /**
     * @ORM\OneToOne(targetEntity="App\Entity\User", inversedBy="cart", cascade={"persist", "remove"})
     * @ORM\JoinColumn(nullable=false)
     */
    private $Email;

    /**
     * @ORM\OneToMany(targetEntity="App\Entity\Cartproduct", mappedBy="cart_id")
     */
    private $cartproducts;

    public function __construct()
    {
        $this->cartproducts = new ArrayCollection();
    }

    public function getId(): ?int
    {
        return $this->id;
    }

    public function getCartId(): ?string
    {
        return $this->cart_id;
    }

    public function setCartId(string $cart_id): self
    {
        $this->cart_id = $cart_id;

        return $this;
    }

    public function getEmail(): ?User
    {
        return $this->Email;
    }

    public function setEmail(User $Email): self
    {
        $this->Email = $Email;

        return $this;
    }

    /**
     * @return Collection|Cartproduct[]
     */
    public function getCartproducts(): Collection
    {
        return $this->cartproducts;
    }

    public function addCartproduct(Cartproduct $cartproduct): self
    {
        if (!$this->cartproducts->contains($cartproduct)) {
            $this->cartproducts[] = $cartproduct;
            $cartproduct->setCartId($this);
        }

        return $this;
    }

    public function removeCartproduct(Cartproduct $cartproduct): self
    {
        if ($this->cartproducts->contains($cartproduct)) {
            $this->cartproducts->removeElement($cartproduct);
            // set the owning side to null (unless already changed)
            if ($cartproduct->getCartId() === $this) {
                $cartproduct->setCartId(null);
            }
        }

        return $this;
    }
}
