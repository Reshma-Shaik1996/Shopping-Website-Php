<?php

namespace App\Controller;

use Symfony\Bundle\FrameworkBundle\Controller\AbstractController;
use Symfony\Component\Routing\Annotation\Route;
use Symfony\Component\HttpFoundation\Request;
use Symfony\Component\HttpFoundation\Response;
use App\Entity\Cartproduct;
use App\Repository\CartproductRepository;
class CartproductController extends AbstractController
{
    /**
     * @Route("/cartproduct", name="cartproduct")
     */
    public function index()
    {
        return $this->render('cartproduct/index.html.twig', [
            'controller_name' => 'CartproductController',
        ]);
    }
}
