<?php

namespace App\Controller;

use Symfony\Bundle\FrameworkBundle\Controller\AbstractController;
use Symfony\Component\Routing\Annotation\Route;
use Symfony\Component\HttpFoundation\Request;
use Symfony\Component\HttpFoundation\Response;
use App\Entity\User;
use App\Entity\Product;
use App\Repository\UserRepository;
use FOS\RestBundle\Routing\ClassResourceInterface;

class UserController extends AbstractController
{
    /**
     * @Route("/user", name="user")
     */
    public function index()
    {
        return $this->render('user/index.html.twig', [
            'controller_name' => 'UserController',
        ]);
    }

/**
     * @Route("/useremail", name="useremail")
  
     */
    public function useremail(UserRepository $userRepository,Request $request) {
        $users = $userRepository->findAll(); 
        //methods={"POST"}
        // 
$user = new User();
         // $Email=     $user->setEmail($request->get('email'));
       // $Password =   $user->setPassword($request->get('password'));
       $Email = $request->request->get('email');
       $Password = $request->request->get('password');


       if($Email == "admin@eleq.ca"){
        if($Password == "884422Ww"){ 
            return $this->render('product/menu.html.twig'); 
       }
    }
      
       if($userRepository->findOneBy(['Email' => $Email])){
        if($userRepository->findOneBy(['Password' => $Password])){ 
            return $this->render('user/index.html.twig'); 
       }
       else
       return new Response('User was not found!'); 

    }
        }
     /**
     * @Route("/users", name="users", methods={"GET"})
     */
    public function users(UserRepository $userRepository,Request $request)
    {
       
       // $users = $userRepository->findAll();
        $username=    $request->request->get('username');
        $pass =  $request->request->get('password');
        return $this->render('user/index.html.twig', [
            'users' => $users
        ]);
    }


        


    /**
     * @Route("/users/create", name="user_create")
     */
    public function create_user(Request $request)
    {
        $user = new User();


        $user->setEmail($request->get('username'));
              $user->setPassword($request->get('password'));

        //$user->setPassword($request->get('password'));
      
        $em = $this->getDoctrine()->getManager();

        $em->persist($user);
        $em->flush();

        return new Response('User was created!');
    }


    /**
     * @Route("/users/remove/{id}", name="user_remove")
     */
    public function remove_user($id, UserRepository $userRepository) {
        $user = $userRepository->find($id);

        $em = $this->getDoctrine()->getManager();
        $em->remove($user);
        $em->flush();

        return $this->redirect($this->generateUrl('users'));
    }
}
