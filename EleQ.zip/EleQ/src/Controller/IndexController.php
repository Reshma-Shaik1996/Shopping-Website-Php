<?php

namespace App\Controller;
use App\Entity\Cart;
use App\Entity\User;
use App\Entity\Product;
use App\Repository\CartRepository;
use App\Repository\UserRepository;
use App\Repository\ProductRepository;
use Symfony\Bundle\FrameworkBundle\Controller\AbstractController;
use Symfony\Component\Routing\Annotation\Route;
use Symfony\Component\HttpFoundation\Request;
use Symfony\Component\HttpFoundation\Response;

class IndexController extends AbstractController
{
    /**
     * @Route("/", name="index")
     */
    public function index()
    {
        return $this->render('product.html.twig', [
            'products' =>[
                ['name'=> 'iphone11', 'image'=> 'images/iphone11.jpeg', 'price'=> 999.99],
                ['name'=> 'imac', 'image'=> 'images/imac.jpeg', 'price'=> 1999.99],
                ['name'=> 'ipad pro', 'image'=> 'images/ipad.jpg', 'price'=> 1299.99]
            ]
        ]);
    }

/**
     * @Route("/cart/add/{name}/{price}", name="add_to_cart")
    
     */
    public function addToCartAction($name, $price,ProductRepository $productReepositoy )
    {
       
$items = ['name'=>$name, 'price'=>$price];
         return $this->render('cart.html.twig', ['items'=>$items]);
    }









    /**
     * @Route("/contact", name="contact")
     */
    public function contact()
    {
        return $this->render('contact.html.twig');
    }

/**
     * @Route("/cart", name="cart")
     */
    public function cart()
    {
        return $this->render('cart.html.twig');
    }

/**
     * @Route("/payment", name="payment")
     */
    public function payment()
    {
        return $this->render('payment.html.twig');
    }

    /**
     * @Route("/success", name="success")
     */
    public function success()
    {
        return $this->render('success.html.twig');
    }

     /**
     * @Route("/Addpromotion", name="Addpromotion")
     */
    public function addpromotion(Request $request)
    {
        //need to create a promtion table and entity
        $promotion = get('promotion');
        $promotionArray =["Promotions","gh"];
        array_push($promotionArray,$promotion);
        return $this->render('product.html.twig',[
           'promotionArray'=>["Promotions","gh"]
        ]);
    }
     /**
     * @Route("/removepromotion/{id}", name="removepromotion")
     */
    public function Removepromotion($id)
    {
        $promotionArray.delete($id);
       

       
        return $this->redirect($this->generateUrl('Addpromotion'));

    }
}
