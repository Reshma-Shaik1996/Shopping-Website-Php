<?php

namespace App\Controller;

use Symfony\Bundle\FrameworkBundle\Controller\AbstractController;
use Symfony\Component\Routing\Annotation\Route;
use Symfony\Component\HttpFoundation\Request;
use Symfony\Component\HttpFoundation\Response;
use App\Entity\Product;
use App\Repository\ProductRepository;
class ProductController extends AbstractController
{
    /**
     * @Route("/product", name="product")
     */
    public function index()
    {
        return $this->render('product/index.html.twig', [
            'controller_name' => 'ProductController',
        ]);
    }

    /**
     * @Route("/product/create", name="product_create")
     */
    public function create_product(Request $request)
    {
        $product = new Product();


        $product->setProductId($request->get('product_id'));
              $product->setName($request->get('name'));
              $product->setImage($request->get('image'));
              $product->setPrice($request->get('price'));
              $product->setDescription($request->get('description'));

      
        $em = $this->getDoctrine()->getManager();

        $em->persist($product);
        $em->flush();

        return new Response('product was created!');
    }

}
